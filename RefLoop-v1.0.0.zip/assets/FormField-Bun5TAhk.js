import{c as l,j as s,b as m}from"./index-D6azkAbc.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=l("Plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);function i({label:a,error:e,children:n,className:x,required:c,helpText:t}){return s.jsxs("div",{className:m("flex flex-col space-y-1.5",x),children:[s.jsxs("label",{className:"text-sm font-medium text-stone-700 dark:text-stone-300",children:[a,c&&s.jsx("span",{className:"text-rose-500 ml-1",children:"*"})]}),n,t&&!e&&s.jsx("span",{className:"text-xs text-stone-500 dark:text-stone-400",children:t}),e&&s.jsx("span",{className:"text-xs font-medium text-rose-500",children:e})]})}export{i as F,d as P};
