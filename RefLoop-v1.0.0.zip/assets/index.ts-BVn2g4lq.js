(function(){const H=['button[aria-label^="Connect"]','button[aria-label^="Invite"]','button[aria-label*="to connect"]','.pvs-profile-actions button:has(span:contains("Connect"))'],J=['div.msg-form__contenteditable[contenteditable="true"]','div[aria-label*="Write a message" i][contenteditable="true"]','div[aria-label*="message" i][contenteditable="true"][role="textbox"]','.msg-form__msg-content-container [contenteditable="true"]'],$=['button.msg-form__send-button[aria-label*="Send"]','button[type="submit"][aria-label*="Send"]',".msg-form__send-btn",'button[aria-label="Send"]'],O=["h1.inline.t-24.v-align-middle.break-words",".pv-text-details__left-panel h1",".artdeco-card h1","main h1:first-of-type"],Y=['button[aria-label*="Easy Apply" i]','.jobs-apply-button--top-card button[aria-label*="Easy Apply" i]','.jobs-unified-top-card__content--two-pane button[aria-label*="Easy Apply" i]'],G=["h1.job-details-jobs-unified-top-card__job-title",".jobs-unified-top-card__job-title h1",".jobs-unified-top-card h1","h1.t-24.job-details-jobs-unified-top-card__job-title",".jobs-details__main-content h1"],W=['a[href*="/company/"]',".job-details-jobs-unified-top-card__company-name a",".jobs-unified-top-card__company-name a",'[data-tracking-control-name="public_jobs_topcard-org-name"]',".jobs-unified-top-card__subtitle-top-card a:first-of-type"],K='a[href*="/company/"], .job-details-jobs-unified-top-card__company-name a, .jobs-unified-top-card__company-name a';function h(e,t=document){for(const o of e)try{const n=t.querySelector(o);if(n)return n}catch{}return null}const V=3,F=500;chrome.runtime.onMessage.addListener((e,t,o)=>typeof e=="object"&&e!==null&&e.type==="PASTE_AND_SEND"?(j(e.payload.message,V).then(i=>o(i)).catch(i=>o({success:!1,error:String(i)})),!0):typeof e=="object"&&e!==null&&e.type==="FETCH_CONNECTIONS_REQUEST"?(Z().then(n=>o({connections:n})),!0):!1);async function j(e,t){try{const o=h(J);if(!o)return t>0?(await v(F),j(e,t-1)):{success:!1,error:"Message composer not found after retries"};o.focus(),await X(o),await Q(o,e),await v(200);const n=h($);return n?(n.click(),await v(500),{success:!0}):{success:!1,error:"Send button not found"}}catch(o){return t>0?(await v(F),j(e,t-1)):{success:!1,error:String(o)}}}async function X(e){e.dispatchEvent(new KeyboardEvent("keydown",{key:"a",ctrlKey:!0,bubbles:!0})),await v(50),document.execCommand("selectAll",!1),await v(50)}async function Q(e,t){var o;if(e.contentEditable==="true"){const n=window.getSelection();n&&(n.selectAllChildren(e),n.collapseToEnd()),e.innerHTML="";const i=new InputEvent("input",{data:t,inputType:"insertText",bubbles:!0,cancelable:!0});document.execCommand("insertText",!1,t),e.dispatchEvent(i)}else{const n=(o=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,"value"))==null?void 0:o.set;n&&n.call(e,t),e.dispatchEvent(new Event("input",{bubbles:!0}))}await v(100)}async function Z(){try{return window.location.href.includes("/mynetwork/invite-connect/connections")?Array.from(document.querySelectorAll('a[href*="/in/"]')).map(t=>t.href).filter(t=>t.includes("/in/")).map(t=>ee(t)):[]}catch{return[]}}function ee(e){try{const t=new URL(e);return`${t.origin}${t.pathname.replace(/\/$/,"")}`}catch{return e}}function v(e){return new Promise(t=>setTimeout(t,e))}function w(e=window.location.href){const t=e.split("?")[0];return/\/in\/[^/]+/i.test(t)?"PROFILE_PAGE":/\/company\/[^/]+/i.test(t)?"COMPANY_PAGE":/\/jobs\/(view|collections|search)/i.test(t)?"JOB_PAGE":"OTHER"}let b=null;function te(){w()==="PROFILE_PAGE"&&oe()}function oe(){var i,r,l;if(w()!=="PROFILE_PAGE"){(i=document.getElementById("refloop-profile-floating-btn"))==null||i.remove();return}if(document.getElementById("refloop-profile-floating-btn"))return;const e=h(O),o=((l=(((r=e==null?void 0:e.textContent)==null?void 0:r.trim())??"Contact").split(/\s+/)[0])==null?void 0:l.replace(/[^a-zA-Z]/g,""))??"Contact",n=document.createElement("button");n.id="refloop-profile-floating-btn",n.innerHTML=`⚡ Add ${o} to RefLoop Job`,n.style.cssText=`
    position: fixed;
    bottom: 24px;
    right: 24px;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    background-color: #D97757;
    color: white;
    border: none;
    border-radius: 12px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 4px 16px rgba(217, 119, 87, 0.4);
    z-index: 999999;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    transition: all 0.2s ease;
  `,n.addEventListener("mouseover",()=>{n.style.backgroundColor="#C86545",n.style.transform="translateY(-1px)"}),n.addEventListener("mouseout",()=>{n.style.backgroundColor="#D97757",n.style.transform="translateY(0)"}),n.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation(),D()}),document.body.appendChild(n)}function D(e={}){var a,f,d;b&&b.remove();let t=e.fullName;if(!t){const p=h(O);t=((a=p==null?void 0:p.textContent)==null?void 0:a.trim())??"Contact"}t=t.replace(/[\r\n]+/g," ").replace(/\s+/g," ").trim();const o=((f=t.split(/\s+/)[0])==null?void 0:f.replace(/[^a-zA-Z]/g,""))||"Contact",n=e.profileUrl||window.location.href.split("?")[0],i=e.companyNameHint||ne();b=document.createElement("div"),b.id="refloop-modal-overlay-root",b.style.cssText=`
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.65);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2147483647;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    box-sizing: border-box;
  `;const r=document.createElement("div");r.style.cssText=`
    background: #FAF8F5;
    color: #1C1917;
    border: 1px solid #E8E3DA;
    border-radius: 20px;
    padding: 24px;
    width: 440px;
    max-width: calc(100vw - 32px);
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.3);
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    gap: 16px;
  `,r.innerHTML=`
    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
      <div style="display: flex; align-items: center; gap: 10px;">
        <div style="width: 34px; height: 34px; background: linear-gradient(135deg, #E06D53 0%, #D97757 100%); color: white; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 16px; shadow: 0 2px 8px rgba(217,119,87,0.4);">⚡</div>
        <div>
          <h3 style="margin: 0; font-size: 17px; font-weight: 700; color: #1C1917; line-height: 1.2;">Add Contact to RefLoop</h3>
          <p style="margin: 2px 0 0 0; font-size: 11px; font-weight: 600; color: #D97757;">RefLoop Referral Outreach Pipeline</p>
        </div>
      </div>
      <button id="refloop-close-btn" style="background: none; border: none; font-size: 20px; cursor: pointer; color: #A8A29E; line-height: 1; padding: 4px;" title="Close">✕</button>
    </div>

    <!-- Candidate Preview Card -->
    <div style="background: #F4F0EA; border: 1px solid #E8E3DA; border-radius: 12px; padding: 12px 14px; display: flex; items-center; gap: 12px;">
      <div style="width: 36px; height: 36px; border-radius: 50%; background: #D97757; color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 14px; shrink: 0;">
        ${((d=o[0])==null?void 0:d.toUpperCase())??"C"}
      </div>
      <div style="overflow: hidden; flex: 1;">
        <div style="font-weight: 700; font-size: 14px; color: #1C1917; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${t}</div>
        <div style="font-size: 11px; color: #78716C; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">LinkedIn Profile</div>
      </div>
    </div>

    <div>
      <label style="display: block; font-size: 12px; font-weight: 600; color: #78716C; margin-bottom: 6px;">First Name</label>
      <input id="refloop-input-firstname" type="text" value="${o}" style="width: 100%; box-sizing: border-box; padding: 10px 14px; border: 1px solid #E8E3DA; border-radius: 10px; font-size: 13px; background: white; color: #1C1917; font-weight: 500; outline: none;" />
    </div>

    <div>
      <label style="display: block; font-size: 12px; font-weight: 600; color: #78716C; margin-bottom: 6px;">Target Job Posting</label>
      <select id="refloop-select-job" style="width: 100%; box-sizing: border-box; padding: 10px 14px; border: 1px solid #E8E3DA; border-radius: 10px; font-size: 13px; background: white; color: #1C1917; font-weight: 500; outline: none; cursor: pointer;">
        <option value="">Loading jobs...</option>
      </select>
    </div>

    <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 6px;">
      <button id="refloop-cancel-btn" style="padding: 9px 18px; border: 1px solid #E8E3DA; background: white; border-radius: 10px; font-size: 13px; font-weight: 600; cursor: pointer; color: #78716C;">Cancel</button>
      <button id="refloop-submit-btn" style="padding: 9px 20px; border: none; background: #D97757; color: white; border-radius: 10px; font-size: 13px; font-weight: 600; cursor: pointer; box-shadow: 0 4px 12px rgba(217, 119, 87, 0.3);">+ Add ${o} to RefLoop</button>
    </div>
  `,b.appendChild(r),document.body.appendChild(b);const l=r.querySelector("#refloop-close-btn"),c=r.querySelector("#refloop-cancel-btn");l==null||l.addEventListener("click",()=>b==null?void 0:b.remove()),c==null||c.addEventListener("click",()=>b==null?void 0:b.remove()),(async()=>{try{const u=((await chrome.storage.local.get("jobs:v1"))["jobs:v1"]??[]).filter(m=>m.status==="ACTIVE"),y=r.querySelector("#refloop-select-job");if(!y)return;if(u.length===0)y.innerHTML='<option value="">No active jobs in RefLoop. Create one first!</option>';else if(y.innerHTML=u.map(m=>`<option value="${m.id}">${m.companyName} — ${m.jobTitle}</option>`).join(""),i){const m=u.findIndex(g=>g.companyName.toLowerCase().includes(i.toLowerCase())||i.toLowerCase().includes(g.companyName.toLowerCase()));m>=0&&(y.selectedIndex=m)}}catch{const p=r.querySelector("#refloop-select-job");p&&(p.innerHTML='<option value="">Failed to load jobs</option>')}})();const s=r.querySelector("#refloop-submit-btn");s==null||s.addEventListener("click",()=>{var u,y,m;const p=(u=r.querySelector("#refloop-input-firstname"))==null?void 0:u.value,x=(y=r.querySelector("#refloop-select-job"))==null?void 0:y.value;if(!x){alert("Please select a target job posting!");return}if(s.innerText="Adding Contact...",s.disabled=!0,!((m=chrome.runtime)!=null&&m.id)){alert("RefLoop extension context was invalidated (e.g. extension updated). Please refresh the page!"),s.innerText=`+ Add ${o} to RefLoop`,s.disabled=!1;return}chrome.runtime.sendMessage({type:"ADD_LINKEDIN_CONTACT_REQUEST",payload:{jobPostingId:x,firstName:p||o,linkedinProfileUrl:n,fullNameRaw:t}},g=>{if(b==null||b.remove(),chrome.runtime.lastError){console.warn("[RefLoop] Error adding contact:",chrome.runtime.lastError.message),alert("Could not communicate with RefLoop extension background script. Please refresh the page.");return}g!=null&&g.success?ie(`✓ Added ${p||o} to RefLoop job!`):alert(`Could not add contact: ${(g==null?void 0:g.error)??"Unknown error"}`)})})}function ne(){const e=window.location.pathname.match(/\/company\/([^/]+)/i);if(e&&e[1])return e[1].replace(/-/g," ")}function ie(e){const t=document.createElement("div");t.innerText=e,t.style.cssText=`
    position: fixed;
    bottom: 24px;
    right: 24px;
    padding: 12px 20px;
    background-color: #1C1917;
    color: white;
    border-radius: 12px;
    font-size: 13px;
    font-weight: 600;
    box-shadow: 0 8px 24px rgba(0,0,0,0.25);
    z-index: 2147483647;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  `,document.body.appendChild(t),setTimeout(()=>t.remove(),4e3)}function re(){var o;if(w()!=="JOB_PAGE"){(o=document.getElementById("refloop-job-injector-btn"))==null||o.remove();return}let e=0;const t=setInterval(()=>{e++,(le()||e>=5)&&clearInterval(t)},800)}function le(){var n;if(w()!=="JOB_PAGE")return(n=document.getElementById("refloop-job-injector-btn"))==null||n.remove(),!0;if(document.getElementById("refloop-job-injector-btn"))return!0;const e=h(G);if(!e)return!1;const t=h(W),o=document.createElement("button");return o.id="refloop-job-injector-btn",o.innerHTML="⚡ Add to RefLoop",o.style.cssText=`
    margin-left: 12px;
    padding: 6px 14px;
    background-color: #D97757;
    color: white;
    border: none;
    border-radius: 16px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(217,119,87,0.3);
    z-index: 9999;
    vertical-align: middle;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  `,o.addEventListener("click",i=>{var p,x,u,y;i.preventDefault(),i.stopPropagation();const r=((p=e.textContent)==null?void 0:p.trim())??"Job Posting",l=h([K]);let c=(x=t==null?void 0:t.textContent)==null?void 0:x.trim();!c&&((u=l==null?void 0:l.textContent)!=null&&u.trim())&&(c=l.textContent.trim()),c||(c="Company");const s=window.location.href.split("?")[0],f=h(Y)!==null?"EASY_APPLY":"COMPANY_SITE";let d;if(l!=null&&l.href){const m=l.href.match(/\/company\/([^/]+)/);m&&(d=m[1])}if(o.innerHTML="✓ Added to RefLoop!",o.style.backgroundColor="#059669",!((y=chrome.runtime)!=null&&y.id)){console.warn("[RefLoop] Extension context invalidated. Please refresh the page.");return}chrome.runtime.sendMessage({type:"ADD_JOB_REQUEST",payload:{companyName:c,jobTitle:r,jobLink:s,sourceType:f,companyLinkedInSlug:d}},()=>{if(chrome.runtime.lastError){console.warn("[RefLoop] Message send error:",chrome.runtime.lastError.message);return}se(c,r)})}),e.appendChild(o),!0}function se(e,t){const o=document.createElement("div");o.style.cssText=`
    position: fixed;
    bottom: 24px;
    right: 24px;
    padding: 14px 20px;
    background-color: #1C1917;
    color: white;
    border-radius: 14px;
    font-size: 13px;
    font-weight: 500;
    box-shadow: 0 8px 24px rgba(0,0,0,0.25);
    z-index: 999999;
    display: flex;
    align-items: center;
    gap: 12px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  `,o.innerHTML=`
    <div>
      <div style="font-weight: 700; color: #10B981;">✓ Job Added to RefLoop!</div>
      <div style="font-size: 11px; color: #A8A29E;">${t} at ${e}</div>
    </div>
    <button id="refloop-toast-dash-btn" style="padding: 6px 12px; background: #D97757; color: white; border: none; border-radius: 8px; font-size: 12px; font-weight: 600; cursor: pointer;">Open Dashboard ↗</button>
  `,document.body.appendChild(o);const n=o.querySelector("#refloop-toast-dash-btn");n==null||n.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_DASHBOARD"}),o.remove()}),setTimeout(()=>o.remove(),6e3)}let z=!1;function ae(){z||(z=!0,document.addEventListener("click",e=>{const t=e.target;if(!t)return;(H.some(n=>{try{return t.matches(n)||t.closest(n)!==null}catch{return!1}})||ce(t))&&de(t)},!0))}function ce(e){try{const t=(e.textContent||"").trim(),o=e.getAttribute("aria-label")||"";return e.tagName==="BUTTON"||e.tagName==="SPAN"||e.closest("button")!==null?/^connect$/i.test(t)||/^invite$/i.test(t)||/connect/i.test(o)||/invite.*to connect/i.test(o):!1}catch{return!1}}function de(e){var s,a,f;const t=e.closest("li, .artdeco-card, .org-people-profile-card, [data-chameleon-result-item], .entity-result, .pv-top-card, main")||document.body;let o;const n=t.querySelector('.org-people-profile-card__profile-title, .entity-result__title-text a, a[href*="/in/"] span[aria-hidden="true"], .pv-text-details__left-panel h1, main h1');if((s=n==null?void 0:n.textContent)!=null&&s.trim()&&(o=n.textContent.trim()),!o){const d=t.querySelector('a[href*="/in/"]');(a=d==null?void 0:d.textContent)!=null&&a.trim()&&(o=d.textContent.trim())}if(!o){const d=t.querySelector("h1, h2, h3, h4");(f=d==null?void 0:d.textContent)!=null&&f.trim()&&(o=d.textContent.trim())}(!o||o.length<2)&&(o="Contact");let i;const r=t.querySelector('a[href*="/in/"]');r!=null&&r.href?i=r.href.split("?")[0]:i=window.location.href.split("?")[0];let l;const c=window.location.pathname.match(/\/company\/([^/]+)/i);c&&c[1]&&(l=c[1].replace(/-/g," ")),setTimeout(()=>{D({fullName:o,profileUrl:i,companyNameHint:l})},250)}function N(){try{return new URL(window.location.href).searchParams.get("currentJobId")}catch{return null}}function pe(){var r,l,c;const e=N();if(e){const s=Array.from(document.querySelectorAll(`a[href*="/jobs/view/${e}"]`));let a=null,f=0;for(const d of s){const p=((r=d.textContent)==null?void 0:r.trim())??"";p.length>f&&(a=d,f=p.length)}if(a&&f>2)return{el:a,text:a.textContent.trim()}}const t=Array.from(document.querySelectorAll("h1"));for(const s of t){const a=((l=s.textContent)==null?void 0:l.trim())??"";if(a.length>3)return{el:s,text:a}}const o=Array.from(document.querySelectorAll('a[href*="/jobs/view/"]'));let n=null,i=0;for(const s of o){const a=((c=s.textContent)==null?void 0:c.trim())??"";a.length>i&&(n=s,i=a.length)}return n&&i>3?{el:n,text:n.textContent.trim()}:null}function fe(e){var r,l,c;let t=e.parentElement,o=0;for(;t&&o<10;){const s=t.querySelector('a[href*="/company/"]');if(s){const a=(r=s.textContent)==null?void 0:r.trim();return a&&a.length>0?a:ue(s.href)}t=t.parentElement,o++}const n=Array.from(document.querySelectorAll('a[href*="/company/"]')),i=n.find(s=>!!(e.compareDocumentPosition(s)&Node.DOCUMENT_POSITION_FOLLOWING));if((l=i==null?void 0:i.textContent)!=null&&l.trim())return i.textContent.trim();for(const s of n){const a=(c=s.textContent)==null?void 0:c.trim();if(a&&a.length>0)return a}return""}function ue(e){const t=e.match(/\/company\/([^/?#]+)/);return t!=null&&t[1]?t[1].split("-").map(o=>o.charAt(0).toUpperCase()+o.slice(1)).join(" "):""}function I(){const e=pe();if(!e)return null;const{el:t,text:o}=e,n=fe(t),i=N();let r;return i?r=`${window.location.origin}/jobs/view/${i}/`:r=window.location.href.split("?")[0],{jobTitle:o,companyName:n,jobLink:r}}function M(e=8,t=500){return new Promise(o=>{const n=I();if(n){o(n);return}let i=0;const r=setInterval(()=>{i++;const l=I();(l||i>=e)&&(clearInterval(r),o(l))},t)})}const S="refloop-jobs-floating-widget",be="refloop-jobs-tab",L="refloop-jobs-panel";let _=!1,k="";function me(){R();const t=new URL(window.location.href).searchParams.get("currentJobId")??"";xe(t),t&&(k=t,q(t))}function R(){var e;(e=document.getElementById(S))==null||e.remove(),_=!1,k=""}function ye(){if(document.getElementById("refloop-widget-styles"))return;const e=document.createElement("style");e.id="refloop-widget-styles",e.textContent=`
    #${S} * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      line-height: normal;
    }
    @keyframes refloop-pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.3; }
    }
  `,document.head.appendChild(e)}function xe(e){if(document.getElementById(S))return;ye();const t=document.createElement("div");t.id=S,t.style.cssText=`
    position: fixed;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    display: flex;
    flex-direction: row-reverse;
    align-items: center;
    pointer-events: none;
  `;const o=document.createElement("button");o.id=be,o.title="RefLoop — Add Job to Tracker",o.style.cssText=`
    all: unset;
    width: 40px;
    height: 92px;
    background: linear-gradient(180deg, #E06D53 0%, #D97757 100%);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-right: none;
    border-radius: 12px 0 0 12px;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    padding: 10px 0;
    box-shadow: -4px 0 20px rgba(0, 0, 0, 0.3);
    transition: width 0.2s ease, background 0.2s ease, transform 0.2s ease;
    pointer-events: auto;
    flex-shrink: 0;
    box-sizing: border-box;
  `,o.innerHTML=`
    <div style="
      width: 24px;
      height: 24px;
      background: rgba(255, 255, 255, 0.22);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
      line-height: 1;
    ">⚡</div>
    <span style="
      writing-mode: vertical-rl;
      text-orientation: mixed;
      transform: rotate(180deg);
      font-size: 10px;
      font-weight: 800;
      color: #FFFFFF;
      letter-spacing: 1.5px;
      display: block;
      line-height: 1;
      text-transform: uppercase;
      margin-bottom: 2px;
    ">REFLOOP</span>
  `,o.addEventListener("mouseenter",()=>{o.style.background="linear-gradient(180deg, #C86545 0%, #BF6640 100%)",o.style.width="44px"}),o.addEventListener("mouseleave",()=>{o.style.background="linear-gradient(180deg, #E06D53 0%, #D97757 100%)",o.style.width="40px"}),o.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation(),he()}),t.appendChild(o);const n=document.createElement("div");n.id=L,n.style.cssText=`
    width: 310px;
    background: #18181B;
    border: 1px solid #3F3F46;
    border-right: none;
    border-radius: 16px 0 0 16px;
    box-shadow: -12px 0 36px rgba(0,0,0,0.5);
    padding: 20px;
    transform: translateX(100%);
    opacity: 0;
    visibility: hidden;
    pointer-events: none;
    transition: transform 0.3s cubic-bezier(0.32, 0.72, 0, 1), opacity 0.2s ease, visibility 0.3s;
    overflow: hidden;
    position: relative;
    box-sizing: border-box;
  `,n.innerHTML=E(),t.appendChild(n),document.body.appendChild(t),A(n),e&&setTimeout(()=>U(),800)}function E(e){const t=(e==null?void 0:e.companyName)??"",o=(e==null?void 0:e.jobTitle)??"",n=(e==null?void 0:e.jobLink)??"";return e?`
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;">
        <div style="
          width:30px;height:30px;min-width:30px;
          background:linear-gradient(135deg,#E06D53,#D97757);
          border-radius:8px;
          display:flex;align-items:center;justify-content:center;
          font-size:15px;line-height:1;
        ">⚡</div>
        <div style="min-width:0;">
          <div style="font-size:13px;font-weight:700;color:#F4F4F5;line-height:1.3;">RefLoop</div>
          <div style="font-size:9px;font-weight:600;color:#D97757;letter-spacing:0.8px;line-height:1.3;">REFERRAL TRACKER</div>
        </div>
      </div>
      <button id="refloop-panel-close" style="
        all:unset;cursor:pointer;
        width:24px;height:24px;min-width:24px;
        display:flex;align-items:center;justify-content:center;
        color:#71717A;font-size:14px;line-height:1;
        border-radius:6px;
        transition:background 0.15s, color 0.15s;
      " title="Close">✕</button>
    </div>

    <div style="height:1px;background:#3F3F46;margin-bottom:16px;"></div>

    <div id="refloop-panel-form">
      <div style="margin-bottom:14px;">
        <label style="display:block;font-size:10px;font-weight:700;color:#A1A1AA;margin-bottom:6px;letter-spacing:0.8px;text-transform:uppercase;">Company</label>
        <input id="refloop-widget-company"
          type="text"
          value="${C(t)}"
          placeholder="e.g. Visa, Google"
          style="
            width:100%;box-sizing:border-box;
            padding:10px 12px;
            background:#27272A;border:1px solid #3F3F46;
            border-radius:10px;font-size:13px;color:#F4F4F5;
            font-family:inherit;outline:none;
            transition:border-color 0.15s;
          "
        />
      </div>

      <div style="margin-bottom:16px;">
        <label style="display:block;font-size:10px;font-weight:700;color:#A1A1AA;margin-bottom:6px;letter-spacing:0.8px;text-transform:uppercase;">Job Title</label>
        <input id="refloop-widget-title"
          type="text"
          value="${C(o)}"
          placeholder="e.g. Sr. Software Engineer"
          style="
            width:100%;box-sizing:border-box;
            padding:10px 12px;
            background:#27272A;border:1px solid #3F3F46;
            border-radius:10px;font-size:13px;color:#F4F4F5;
            font-family:inherit;outline:none;
            transition:border-color 0.15s;
          "
        />
      </div>

      <input id="refloop-widget-link" type="hidden" value="${C(n)}" />

      <button id="refloop-widget-submit" style="
        all:unset;
        display:flex;align-items:center;justify-content:center;gap:6px;
        width:100%;box-sizing:border-box;
        padding:11px 16px;
        background:linear-gradient(135deg,#E06D53,#D97757);
        color:white;border-radius:10px;
        font-size:13px;font-weight:700;cursor:pointer;
        box-shadow:0 4px 14px rgba(217,119,87,0.35);
        transition:opacity 0.15s,transform 0.1s;
        font-family:inherit;
        text-align:center;
      ">
        <span style="font-size:15px;line-height:1;">+</span>
        <span>Add Job to RefLoop</span>
      </button>

      <div id="refloop-widget-error" style="
        display:none;margin-top:10px;
        font-size:11px;color:#F87171;text-align:center;
      "></div>
    </div>
  `:`
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
        <div style="
          width:30px;height:30px;min-width:30px;
          background:linear-gradient(135deg,#E06D53,#D97757);
          border-radius:8px;
          display:flex;align-items:center;justify-content:center;
          font-size:15px;line-height:1;
        ">⚡</div>
        <div>
          <div style="font-size:13px;font-weight:700;color:#F4F4F5;line-height:1.3;">RefLoop</div>
          <div style="font-size:9px;font-weight:600;color:#D97757;letter-spacing:0.8px;line-height:1.3;">REFERRAL TRACKER</div>
        </div>
      </div>
      <div style="height:1px;background:#3F3F46;margin-bottom:16px;"></div>
      <div style="text-align:center;padding:24px 0;color:#71717A;font-size:12px;">
        <div style="font-size:22px;margin-bottom:10px;animation:refloop-pulse 1.2s ease-in-out infinite;">⚡</div>
        Reading job details…
      </div>
    `}function ge(e,t){return`
    <div style="text-align:center;padding:20px 0;">
      <div style="font-size:36px;margin-bottom:10px;line-height:1;">✅</div>
      <div style="font-size:14px;font-weight:700;color:#34D399;margin-bottom:6px;line-height:1.3;">Added to RefLoop!</div>
      <div style="font-size:11px;color:#A1A1AA;margin-bottom:16px;line-height:1.4;word-break:break-word;">${C(t)} at ${C(e)}</div>
      <button id="refloop-widget-open-dash" style="
        all:unset;
        display:inline-flex;align-items:center;justify-content:center;gap:4px;
        padding:9px 18px;
        background:#27272A;border:1px solid #3F3F46;
        color:#F4F4F5;border-radius:10px;font-size:12px;font-weight:600;
        cursor:pointer;font-family:inherit;
        transition:background 0.15s;
      ">Open Dashboard <span style="font-size:14px;">↗</span></button>
    </div>
  `}function U(){const e=document.getElementById(L);e&&(e.style.transform="translateX(0)",e.style.opacity="1",e.style.visibility="visible",e.style.pointerEvents="auto",_=!0)}function B(){const e=document.getElementById(L);e&&(e.style.transform="translateX(100%)",e.style.opacity="0",e.style.visibility="hidden",e.style.pointerEvents="none",_=!1)}function he(){_?B():U()}async function q(e){const t=document.getElementById(L);if(!t)return;t.innerHTML=E(),A(t);const o=await M();t.isConnected&&(o?t.innerHTML=E(o):t.innerHTML=E({jobTitle:"",companyName:"",jobLink:`${window.location.origin}/jobs/view/${e}/`}),A(t))}function A(e){var n;const t=e.querySelector("#refloop-panel-close");t==null||t.addEventListener("click",()=>B()),t==null||t.addEventListener("mouseenter",()=>{t.style.background="#27272A",t.style.color="#F4F4F5"}),t==null||t.addEventListener("mouseleave",()=>{t.style.background="transparent",t.style.color="#71717A"}),e.querySelectorAll('input[type="text"]').forEach(i=>{i.addEventListener("focus",()=>{i.style.borderColor="#D97757"}),i.addEventListener("blur",()=>{i.style.borderColor="#3F3F46"})});const o=e.querySelector("#refloop-widget-submit");o==null||o.addEventListener("click",()=>void ve(e)),o==null||o.addEventListener("mouseenter",()=>{o&&(o.style.opacity="0.9",o.style.transform="translateY(-1px)")}),o==null||o.addEventListener("mouseleave",()=>{o&&(o.style.opacity="1",o.style.transform="translateY(0)")}),(n=e.querySelector("#refloop-widget-open-dash"))==null||n.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_DASHBOARD"})})}async function ve(e){var a;const t=e.querySelector("#refloop-widget-company"),o=e.querySelector("#refloop-widget-title"),n=e.querySelector("#refloop-widget-link"),i=e.querySelector("#refloop-widget-error"),r=e.querySelector("#refloop-widget-submit"),l=(t==null?void 0:t.value.trim())??"",c=(o==null?void 0:o.value.trim())??"",s=(n==null?void 0:n.value)??window.location.href.split("?")[0];if(!l||!c){i&&(i.style.display="block",i.textContent="Please fill in both Company and Job Title.");return}if(r&&(r.style.opacity="0.6",r.style.pointerEvents="none",r.innerHTML='<span style="opacity:0.8;">Adding…</span>'),!((a=chrome.runtime)!=null&&a.id)){i&&(i.style.display="block",i.textContent="Extension context lost — please refresh the page."),r&&(r.style.opacity="1",r.style.pointerEvents="auto",r.innerHTML='<span style="font-size:15px;line-height:1;">+</span><span>Add Job to RefLoop</span>');return}try{const f=!!document.querySelector('button[aria-label*="Easy Apply" i]');await new Promise((p,x)=>{chrome.runtime.sendMessage({type:"ADD_JOB_REQUEST",payload:{companyName:l,jobTitle:c,jobLink:s,sourceType:f?"EASY_APPLY":"COMPANY_SITE"}},u=>{if(chrome.runtime.lastError)return x(chrome.runtime.lastError);u!=null&&u.success?p():x(new Error((u==null?void 0:u.error)??"Unknown error"))})});const d=e.querySelector("#refloop-panel-form");d&&(d.innerHTML=ge(l,c),A(e))}catch(f){console.error("[RefLoop] Widget submit error:",f),i&&(i.style.display="block",i.textContent=`Error: ${String(f)}`),r&&(r.style.opacity="1",r.style.pointerEvents="auto",r.innerHTML='<span style="font-size:15px;line-height:1;">+</span><span>Add Job to RefLoop</span>')}}function C(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function we(e){if(e===k)return;k=e;const t=document.getElementById(L);if(t){if(!e){t.innerHTML=E(),A(t);return}q(e)}}chrome.runtime.onMessage.addListener((e,t,o)=>e!==null&&typeof e=="object"&&e.type==="GET_CURRENT_JOB_DETAILS"?(M().then(n=>{o({success:!0,details:n})}),!0):!1);function P(){var t,o,n,i;const e=w();e==="PROFILE_PAGE"?((t=document.getElementById("refloop-job-injector-btn"))==null||t.remove(),R(),te()):e==="JOB_PAGE"?((o=document.getElementById("refloop-profile-floating-btn"))==null||o.remove(),re(),me()):((n=document.getElementById("refloop-job-injector-btn"))==null||n.remove(),(i=document.getElementById("refloop-profile-floating-btn"))==null||i.remove(),R()),ae()}P();let T=window.location.href;const Ee=new MutationObserver(()=>{const e=window.location.href;if(e===T)return;const t=new URL(T).searchParams.get("currentJobId")??"",o=new URL(T).pathname;T=e;const n=new URL(e).searchParams.get("currentJobId")??"",i=new URL(e).pathname;if(o!==i){P();return}if(w()==="JOB_PAGE"&&n!==t){we(n);return}P()});Ee.observe(document.body,{subtree:!0,childList:!0});
})()
