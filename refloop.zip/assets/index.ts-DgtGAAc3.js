(function(){const p=[{name:"Greenhouse",pattern:/boards\.greenhouse\.io\/([^/]+)\/jobs\/(\d+)/i,extractJobId:e=>e[2]??"",extractCompany:e=>e[1]??""},{name:"Lever",pattern:/jobs\.lever\.co\/([^/]+)\/([0-9a-f-]{36})/i,extractJobId:e=>e[2]??"",extractCompany:e=>e[1]??""},{name:"Workday",pattern:/([^.]+)\.wd\d+\.myworkdayjobs\.com.*\/job\/[^/]+\/([^/?#]+)/i,extractJobId:e=>e[2]??"",extractCompany:e=>e[1]??""},{name:"SmartRecruiters",pattern:/jobs\.smartrecruiters\.com\/([^/]+)\/(\d+)-/i,extractJobId:e=>e[2]??"",extractCompany:e=>e[1]??""},{name:"iCIMS",pattern:/([^.]+)\.icims\.com\/jobs\/(\d+)\//i,extractJobId:e=>e[2]??"",extractCompany:e=>e[1]??""},{name:"Ashby",pattern:/jobs\.ashbyhq\.com\/([^/]+)\/([0-9a-f-]{36})/i,extractJobId:e=>e[2]??"",extractCompany:e=>e[1]??""},{name:"Taleo",pattern:/taleo\.net\/careersection\/.+?\/jobdetail\.ftl.*[?&]job=([^&]+)/i,extractJobId:e=>e[1]??"",extractCompany:e=>{var o;const t=(o=e.input)==null?void 0:o.match(/^https?:\/\/([^.]+)\.taleo\.net/i);return(t==null?void 0:t[1])??"unknown"}}];function m(e){for(const t of p){const o=e.match(t.pattern);if(o){const n=t.extractCompany(o),r=t.extractJobId(o);return{ats:t.name,companySlug:n,companyJobId:r,companyNameFromUrl:l(n)}}}return null}function l(e){return e.replace(/[-_]/g," ").replace(/\b\w/g,t=>t.toUpperCase())}const d=m(window.location.href);d&&setTimeout(()=>{b(d)},1e3);function b(e){if(document.getElementById("refloop-ats-btn"))return;const t=document.createElement("button");t.id="refloop-ats-btn",t.innerHTML=`⚡ Add to RefLoop (${e.ats})`,t.style.cssText=`
    position: fixed;
    bottom: 24px;
    right: 24px;
    padding: 10px 18px;
    background-color: #D97757;
    color: white;
    border: none;
    border-radius: 12px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 4px 16px rgba(217,119,87,0.35);
    z-index: 99999;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    transition: all 0.2s ease;
  `,t.addEventListener("mouseover",()=>{t.style.backgroundColor="#C86545"}),t.addEventListener("mouseout",()=>{t.style.backgroundColor="#D97757"}),t.addEventListener("click",()=>{var r,a,i,s,c;let o=((i=(a=(r=document.title.split("|")[0])==null?void 0:r.split("-")[0])==null?void 0:a.split("–")[0])==null?void 0:i.trim())??"Job Posting";const n=document.querySelector("h1");if((s=n==null?void 0:n.textContent)!=null&&s.trim()&&(o=n.textContent.trim()),t.innerHTML="✓ Added to RefLoop!",t.style.backgroundColor="#059669",!((c=chrome.runtime)!=null&&c.id)){console.warn("[RefLoop] Extension context invalidated. Please refresh the page.");return}chrome.runtime.sendMessage({type:"ADD_JOB_REQUEST",payload:{companyName:e.companyNameFromUrl,jobTitle:o,jobLink:window.location.href,sourceType:"COMPANY_SITE",companyJobId:e.companyJobId}},x=>{if(chrome.runtime.lastError){console.warn("[RefLoop] Error sending ATS job request:",chrome.runtime.lastError.message);return}u(e.companyNameFromUrl,o)})}),document.body.appendChild(t)}function u(e,t){const o=document.createElement("div");o.style.cssText=`
    position: fixed;
    bottom: 72px;
    right: 24px;
    padding: 14px 20px;
    background-color: #1C1917;
    color: white;
    border-radius: 14px;
    font-size: 13px;
    font-weight: 500;
    box-shadow: 0 8px 24px rgba(0,0,0,0.25);
    z-index: 999999;
    display: flex;
    align-items: center;
    gap: 12px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  `,o.innerHTML=`
    <div>
      <div style="font-weight: 700; color: #10B981;">✓ Job Added to RefLoop!</div>
      <div style="font-size: 11px; color: #A8A29E;">${t} at ${e}</div>
    </div>
    <button id="refloop-toast-dash-btn" style="padding: 6px 12px; background: #D97757; color: white; border: none; border-radius: 8px; font-size: 12px; font-weight: 600; cursor: pointer;">Open Dashboard ↗</button>
  `,document.body.appendChild(o);const n=o.querySelector("#refloop-toast-dash-btn");n==null||n.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_DASHBOARD"}),o.remove()}),setTimeout(()=>o.remove(),6e3)}
})()
