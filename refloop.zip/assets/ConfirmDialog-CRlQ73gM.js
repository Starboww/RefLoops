import{c as h,j as a,D as x,e as j,f as k,h as D,k as f,i as m,B as i}from"./index-CmsZJtSC.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=h("Users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["path",{d:"M16 3.13a4 4 0 0 1 0 7.75",key:"1da9ce"}]]);function g({open:r,onOpenChange:s,title:l,description:c,confirmLabel:n="Confirm",cancelLabel:o="Cancel",variant:t="primary",isLoading:e=!1,onConfirm:d}){return a.jsx(x,{open:r,onOpenChange:s,children:a.jsxs(j,{children:[a.jsxs(k,{children:[a.jsx(D,{children:l}),a.jsx(f,{children:c})]}),a.jsxs(m,{className:"mt-4 gap-2",children:[a.jsx(i,{variant:"outline",onClick:()=>s(!1),disabled:e,children:o}),a.jsx(i,{variant:t,onClick:d,isLoading:e,children:n})]})]})})}export{g as C,y as U};
