(function(){const ye=['button[aria-label^="Connect"]','button[aria-label^="Invite"]','button[aria-label*="to connect"]','.pvs-profile-actions button:has(span:contains("Connect"))'],W=['div.msg-form__contenteditable[contenteditable="true"]','div[aria-label*="Write a message" i][contenteditable="true"]','div[aria-label*="message" i][contenteditable="true"][role="textbox"]','.msg-form__msg-content-container [contenteditable="true"]'],he=["button.msg-form__send-button",'button[type="submit"].msg-form__send-button','button[type="submit"][aria-label*="Send" i]','button.msg-form__send-button[aria-label*="Send" i]','form.msg-form button[type="submit"]','button[aria-label="Send" i]','button[aria-label*="Send" i]',".msg-form__send-btn"],xe=['button[aria-label^="Message"]','a[aria-label^="Message"]','.pvs-profile-actions button[aria-label*="Message" i]',".pv-s-profile-actions__message",".message-anywhere-button",'[data-control-name="message"]','a[href*="/messaging/compose"]','a[href*="messaging/thread/new"]'],ve=["main section:first-of-type h2","main section:first-of-type h1","section.pv-top-card h2","section.pv-top-card h1",".pv-top-card h2",".pv-top-card h1",".pv-text-details__left-panel h2",".pv-text-details__left-panel h1","h2.inline.t-24.v-align-middle.break-words","h1.inline.t-24.v-align-middle.break-words","h2.inline.t-24","h1.inline.t-24",".artdeco-card h2",".artdeco-card h1","main h2:first-of-type","main h1:first-of-type"],we=new Set(["about","experience","education","skills","activity","interests","featured","languages","analytics","resources","licenses & certifications","projects","volunteering","recommendations","courses","honors & awards","organizations","causes","more profiles for you","people also viewed","people you may know","people also follow","pages people also follow","people also search for","similar pages","affiliated company","affiliated companies","suggested","messaging","notifications","feed","jobs","mynetwork"]);function C(e){return e?e.replace(/\((?:He\/Him|She\/Her|They\/Them|He\/They|She\/They|Ze\/Zir|Any pronouns)[^)]*\)/gi,"").replace(/\b(?:He\/Him|She\/Her|They\/Them)\b/gi,"").replace(/·\s*\d+(st|nd|rd|th)?/gi,"").replace(/\b\d+(st|nd|rd|th)\b/gi,"").replace(/[\r\n\t]+/g," ").replace(/\s+/g," ").replace(/^[^a-zA-Z0-9]+|[^a-zA-Z0-9.\s]+$/g,"").trim():""}function A(e){if(!e||e.length<2)return!1;const t=e.toLowerCase().trim();return we.has(t)||t.startsWith("more profiles")||t.startsWith("people also")||t.startsWith("people you may")||t.startsWith("pages people")||t.startsWith("similar pages")||t.startsWith("view profile")||t.startsWith("show all")?!1:/[a-zA-Z]/.test(e)}function R(){var t,o,r;for(const n of ve)try{const i=document.querySelector(n);if(i){const a=C(i.textContent||"");if(A(a)){const d=((t=a.split(/\s+/)[0])==null?void 0:t.replace(/[^a-zA-Z]/g,""))||"Contact";return{fullName:a,firstName:d}}}}catch{}const e=document.querySelector("main section:first-of-type, .pv-top-card, main .artdeco-card:first-of-type");if(e){const n=e.querySelectorAll("h1, h2, h3");for(const i of n){const a=C(i.textContent||"");if(A(a)){const d=((o=a.split(/\s+/)[0])==null?void 0:o.replace(/[^a-zA-Z]/g,""))||"Contact";return{fullName:a,firstName:d}}}}if(typeof document<"u"&&document.title){const i=document.title.replace(/^\(\d+\)\s*/,"").trim().split(/\s*[\–\—\|\-]\s*/);if(i.length>0&&i[0]){const a=C(i[0]);if(A(a)&&!a.toLowerCase().includes("linkedin")){const d=((r=a.split(/\s+/)[0])==null?void 0:r.replace(/[^a-zA-Z]/g,""))||"Contact";return{fullName:a,firstName:d}}}}return{fullName:"Contact",firstName:"Contact"}}const Ee=['button[aria-label*="Easy Apply" i]','.jobs-apply-button--top-card button[aria-label*="Easy Apply" i]','.jobs-unified-top-card__content--two-pane button[aria-label*="Easy Apply" i]'],_e=["h1.job-details-jobs-unified-top-card__job-title",".jobs-unified-top-card__job-title h1",".jobs-unified-top-card h1","h1.t-24.job-details-jobs-unified-top-card__job-title",".jobs-details__main-content h1"],Ce=['a[href*="/company/"]',".job-details-jobs-unified-top-card__company-name a",".jobs-unified-top-card__company-name a",'[data-tracking-control-name="public_jobs_topcard-org-name"]',".jobs-unified-top-card__subtitle-top-card a:first-of-type"],Ae='a[href*="/company/"], .job-details-jobs-unified-top-card__company-name a, .jobs-unified-top-card__company-name a';function _(e,t=document){for(const o of e)try{const r=t.querySelector(o);if(r)return r}catch{}return null}const X=window;X.__refloop_composer_listener__||(X.__refloop_composer_listener__=!0,chrome.runtime.onMessage.addListener((e,t,o)=>{if(typeof e!="object"||e===null)return!1;const r=e;if(r.type==="PASTE_AND_SEND"){const{message:n}=r.payload;return ae(n).then(i=>o(i)).catch(i=>o({success:!1,error:String(i)})),!0}if(r.type==="OPEN_COMPOSER_AND_SEND"){const{message:n}=r.payload;return Le(n).then(i=>o(i)).catch(i=>o({success:!1,error:String(i)})),!0}return r.type==="FETCH_CONNECTIONS_REQUEST"?(ke().then(n=>o({connections:n})),!0):!1}));async function Le(e){let t=_(W);if(!t){const o=_(xe);if(!o)return{success:!1,error:"Message button not found — is this a 1st-degree connection?"};o.addEventListener("click",n=>n.preventDefault(),{once:!0}),o.dispatchEvent(new MouseEvent("click",{bubbles:!0,cancelable:!0}));const r=await Te(W,8e3,200);if(!r)return{success:!1,error:"Composer did not open after clicking Message button (timeout 8s)."};t=r}return await k(800),ae(e,t)}async function ae(e,t){const o=t??_(W);if(!o)return{success:!1,error:"Composer textarea not found."};o.focus(),await k(100),document.execCommand("selectAll",!1),await k(80),document.execCommand("delete",!1),o.dispatchEvent(new InputEvent("input",{inputType:"deleteContentBackward",bubbles:!0,cancelable:!0})),await k(80),document.execCommand("insertText",!1,e),o.dispatchEvent(new InputEvent("input",{data:e,inputType:"insertText",bubbles:!0,cancelable:!0})),await k(300);const r=_(he);return r?(r.click(),await k(500),{success:!0}):{success:!1,error:"Send button not found."}}function Te(e,t,o){return new Promise(r=>{const n=Date.now(),i=setInterval(()=>{const a=_(e);if(a){clearInterval(i),r(a);return}Date.now()-n>=t&&(clearInterval(i),r(null))},o)})}async function ke(){try{return window.location.href.includes("/mynetwork/invite-connect/connections")?Array.from(document.querySelectorAll('a[href*="/in/"]')).map(t=>t.href).filter(t=>t.includes("/in/")).map(t=>Se(t)):[]}catch{return[]}}function Se(e){try{const t=new URL(e);return`${t.origin}${t.pathname.replace(/\/$/,"")}`}catch{return e}}function k(e){return new Promise(t=>setTimeout(t,e))}function y(e=window.location.href){const t=e.split("?")[0].split("#")[0];return/\/in\/[^/]+/i.test(t)?"PROFILE_PAGE":/\/(?:company|school)\/[^/]+\/people(?:\/|$)/i.test(t)?"COMPANY_PEOPLE_PAGE":/\/(?:company|school)\/[^/]+/i.test(t)?"COMPANY_PAGE":/\/jobs\/(view|collections|search)/i.test(t)?"JOB_PAGE":"OTHER"}let b=null,w=null;function Pe(){y()==="PROFILE_PAGE"&&je()}function je(){var r;if(y()!=="PROFILE_PAGE"){(r=document.getElementById("refloop-profile-floating-btn"))==null||r.remove(),w&&(clearInterval(w),w=null);return}const{firstName:e}=R();let t=document.getElementById("refloop-profile-floating-btn");t||(t=document.createElement("button"),t.id="refloop-profile-floating-btn",t.style.cssText=`
      position: fixed;
      bottom: 24px;
      right: 24px;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 10px 18px;
      background-color: #D97757;
      color: white;
      border: none;
      border-radius: 12px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 4px 16px rgba(217, 119, 87, 0.4);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      transition: all 0.2s ease;
    `,t.addEventListener("mouseover",()=>{t.style.backgroundColor="#C86545",t.style.transform="translateY(-1px)"}),t.addEventListener("mouseout",()=>{t.style.backgroundColor="#D97757",t.style.transform="translateY(0)"}),t.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),V()}),document.body.appendChild(t)),t.innerHTML=`⚡ Add ${e} to RefLoop Job`,w&&clearInterval(w);let o=0;w=setInterval(()=>{var a;if(o++,!((a=chrome.runtime)!=null&&a.id)||y()!=="PROFILE_PAGE"){w&&clearInterval(w);return}const n=R(),i=document.getElementById("refloop-profile-floating-btn");i&&n.firstName&&n.firstName!=="Contact"&&(i.innerHTML=`⚡ Add ${n.firstName} to RefLoop Job`,w&&clearInterval(w)),o>=10&&w&&clearInterval(w)},400)}function V(e={}){var f,p;b&&b.remove();let t=e.fullName,o="Contact";if(!t||t==="Contact"){const c=R();t=c.fullName,o=c.firstName}else if(t=C(t),A(t))o=((f=t.split(/\s+/)[0])==null?void 0:f.replace(/[^a-zA-Z]/g,""))||"Contact";else{const c=R();t=c.fullName,o=c.firstName}const r=e.profileUrl||window.location.href.split("?")[0],n=e.companyNameHint||Ne();b=document.createElement("div"),b.id="refloop-modal-overlay-root",b.style.cssText=`
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.65);
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2147483647;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    box-sizing: border-box;
  `;const i=document.createElement("div");i.style.cssText=`
    background: #FAF8F5;
    color: #1C1917;
    border: 1px solid #E8E3DA;
    border-radius: 20px;
    padding: 24px;
    width: 460px;
    max-width: calc(100vw - 32px);
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.3);
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    gap: 16px;
  `,i.innerHTML=`
    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
      <div style="display: flex; align-items: center; gap: 10px;">
        <div style="width: 36px; height: 36px; background: linear-gradient(135deg, #E06D53 0%, #D97757 100%); color: white; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 16px; box-shadow: 0 2px 8px rgba(217,119,87,0.4);">⚡</div>
        <div>
          <h3 style="margin: 0; font-size: 17px; font-weight: 700; color: #1C1917; line-height: 1.2;">Add Contact to RefLoop</h3>
          <p style="margin: 2px 0 0 0; font-size: 11px; font-weight: 600; color: #D97757;">RefLoop Referral Outreach Pipeline</p>
        </div>
      </div>
      <button id="refloop-close-btn" style="background: none; border: none; font-size: 20px; cursor: pointer; color: #A8A29E; line-height: 1; padding: 4px;" title="Close">✕</button>
    </div>

    <!-- Candidate Preview Card -->
    <div style="background: #F4F0EA; border: 1px solid #E8E3DA; border-radius: 12px; padding: 12px 14px; display: flex; align-items: center; gap: 12px;">
      <div style="width: 38px; height: 38px; border-radius: 50%; background: #D97757; color: white; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 15px; flex-shrink: 0;">
        ${((p=o[0])==null?void 0:p.toUpperCase())??"C"}
      </div>
      <div style="overflow: hidden; flex: 1;">
        <div id="refloop-preview-fullname" style="font-weight: 700; font-size: 14px; color: #1C1917; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${t}</div>
        <div style="font-size: 11px; color: #78716C; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">LinkedIn Profile</div>
      </div>
    </div>

    <div>
      <label style="display: block; font-size: 12px; font-weight: 600; color: #78716C; margin-bottom: 6px;">First Name</label>
      <input id="refloop-input-firstname" type="text" value="${o}" style="width: 100%; height: 42px; min-height: 42px; line-height: 20px; box-sizing: border-box; padding: 0 14px; border: 1.5px solid #E8E3DA; border-radius: 10px; font-size: 13px; background: white; color: #1C1917; font-weight: 600; outline: none;" />
    </div>

    <div>
      <label style="display: block; font-size: 12px; font-weight: 600; color: #78716C; margin-bottom: 6px;">Target Job Posting</label>
      <div style="position: relative;">
        <select id="refloop-select-job" style="width: 100%; height: 42px; min-height: 42px; line-height: 20px; box-sizing: border-box; padding: 0 36px 0 12px; border: 1.5px solid #E8E3DA; border-radius: 10px; font-size: 13px; background-color: #FFFFFF; background-image: url(&quot;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%2378716C' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E&quot;); background-repeat: no-repeat; background-position: right 12px center; color: #1C1917; font-weight: 600; outline: none; cursor: pointer; appearance: none; -webkit-appearance: none; -moz-appearance: none; text-overflow: ellipsis; white-space: nowrap; overflow: hidden; display: block;">
          <option value="">Loading jobs...</option>
        </select>
      </div>
      <!-- Job detail banner to display the full job title & company clearly with word wrap -->
      <div id="refloop-selected-job-info" style="display: none; margin-top: 8px; font-size: 12px; color: #44403C; background: #F4F0EA; border: 1px solid #E8E3DA; border-radius: 8px; padding: 8px 12px; line-height: 1.45; word-break: break-word;">
      </div>
    </div>

    <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 6px;">
      <button id="refloop-cancel-btn" style="padding: 10px 18px; border: 1px solid #E8E3DA; background: white; border-radius: 10px; font-size: 13px; font-weight: 600; cursor: pointer; color: #78716C;">Cancel</button>
      <button id="refloop-submit-btn" style="padding: 10px 20px; border: none; background: #D97757; color: white; border-radius: 10px; font-size: 13px; font-weight: 600; cursor: pointer; box-shadow: 0 4px 12px rgba(217, 119, 87, 0.3);">+ Add ${o} to RefLoop</button>
    </div>
  `,b.appendChild(i),document.body.appendChild(b);const a=i.querySelector("#refloop-close-btn"),d=i.querySelector("#refloop-cancel-btn");a==null||a.addEventListener("click",()=>b==null?void 0:b.remove()),d==null||d.addEventListener("click",()=>b==null?void 0:b.remove());const l=i.querySelector("#refloop-input-firstname"),s=i.querySelector("#refloop-submit-btn");l==null||l.addEventListener("input",()=>{const c=l.value.trim();s&&(s.innerText=`+ Add ${c||"Contact"} to RefLoop`)}),(async()=>{try{const c=await chrome.storage.local.get(["jobs:v1","contacts:v1"]),m=c["jobs:v1"]??[],E=c["contacts:v1"]??[],g=m.filter(h=>h.status==="ACTIVE"),u=i.querySelector("#refloop-select-job"),v=i.querySelector("#refloop-selected-job-info");if(!u)return;const J=r.split("?")[0].split("#")[0].toLowerCase().replace(/\/+$/,""),ge=h=>E.some(x=>{if(x.jobPostingId!==h||x.removedAt||!x.linkedinProfileUrl)return!1;const j=x.linkedinProfileUrl.split("?")[0].split("#")[0].toLowerCase().replace(/\/+$/,"");return j===J||j.endsWith(J)||J.endsWith(j)}),K=()=>{var Q;if(!v)return;const h=u.value,x=g.find(G=>G.id===h),j=ge(h);if(x){if(v.style.display="block",j)v.innerHTML=`
              <div style="color: #DC2626; font-weight: 700; margin-bottom: 2px;">⚠️ Already added to this job posting</div>
              <span style="color: #D97757; font-weight: 700;">💼 Target Job:</span> <strong style="color: #1C1917;">${x.companyName}</strong> — ${x.jobTitle}
            `,s&&(s.disabled=!0,s.style.opacity="0.5",s.innerText="Already in RefLoop Job");else if(v.innerHTML=`<span style="color: #D97757; font-weight: 700;">💼 Target Job:</span> <strong style="color: #1C1917;">${x.companyName}</strong> — ${x.jobTitle}`,s){s.disabled=!1,s.style.opacity="1";const G=((Q=i.querySelector("#refloop-input-firstname"))==null?void 0:Q.value.trim())||o;s.innerText=`+ Add ${G} to RefLoop`}}else v.style.display="none"};if(u.addEventListener("change",K),g.length===0)u.innerHTML='<option value="">No active jobs in RefLoop. Create one first!</option>';else{if(u.innerHTML=g.map(h=>`<option value="${h.id}">${h.companyName} — ${h.jobTitle}</option>`).join(""),n){const h=g.findIndex(x=>x.companyName.toLowerCase().includes(n.toLowerCase())||n.toLowerCase().includes(x.companyName.toLowerCase()));h>=0&&(u.selectedIndex=h)}K()}}catch{const c=i.querySelector("#refloop-select-job");c&&(c.innerHTML='<option value="">Failed to load jobs</option>')}})(),s==null||s.addEventListener("click",()=>{var E,g,u;const c=(E=i.querySelector("#refloop-input-firstname"))==null?void 0:E.value,m=(g=i.querySelector("#refloop-select-job"))==null?void 0:g.value;if(!m){alert("Please select a target job posting!");return}if(s.innerText="Adding Contact...",s.disabled=!0,!((u=chrome.runtime)!=null&&u.id)){alert("RefLoop extension context was invalidated (e.g. extension updated). Please refresh the page!"),s.innerText=`+ Add ${o} to RefLoop`,s.disabled=!1;return}chrome.runtime.sendMessage({type:"ADD_LINKEDIN_CONTACT_REQUEST",payload:{jobPostingId:m,firstName:c||o,linkedinProfileUrl:r,fullNameRaw:t}},v=>{if(b==null||b.remove(),chrome.runtime.lastError){console.warn("[RefLoop] Error adding contact:",chrome.runtime.lastError.message),alert("Could not communicate with RefLoop extension background script. Please refresh the page.");return}v!=null&&v.success?ee(`✓ Added ${c||o} to RefLoop job!`):ee(`⚠️ ${(v==null?void 0:v.error)??"Could not add contact"}`)})})}function Ne(){const e=window.location.pathname.match(/\/company\/([^/]+)/i);if(e&&e[1])return e[1].replace(/-/g," ")}function ee(e){const t=document.createElement("div");t.innerText=e,t.style.cssText=`
    position: fixed;
    bottom: 24px;
    right: 24px;
    padding: 12px 20px;
    background-color: #1C1917;
    color: white;
    border-radius: 12px;
    font-size: 13px;
    font-weight: 600;
    box-shadow: 0 8px 24px rgba(0,0,0,0.25);
    z-index: 2147483647;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  `,document.body.appendChild(t),setTimeout(()=>t.remove(),4e3)}function Ie(){var o;if(y()!=="JOB_PAGE"){(o=document.getElementById("refloop-job-injector-btn"))==null||o.remove();return}let e=0;const t=setInterval(()=>{var n;if(e++,!((n=chrome.runtime)!=null&&n.id)){clearInterval(t);return}(Oe()||e>=5)&&clearInterval(t)},800)}function Oe(){var r;if(y()!=="JOB_PAGE")return(r=document.getElementById("refloop-job-injector-btn"))==null||r.remove(),!0;if(document.getElementById("refloop-job-injector-btn"))return!0;const e=_(_e);if(!e)return!1;const t=_(Ce),o=document.createElement("button");return o.id="refloop-job-injector-btn",o.innerHTML="⚡ Add to RefLoop",o.style.cssText=`
    margin-left: 12px;
    padding: 6px 14px;
    background-color: #D97757;
    color: white;
    border: none;
    border-radius: 16px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(217,119,87,0.3);
    z-index: 9999;
    vertical-align: middle;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  `,o.addEventListener("click",n=>{var c,m,E,g;n.preventDefault(),n.stopPropagation();const i=((c=e.textContent)==null?void 0:c.trim())??"Job Posting",a=_([Ae]);let d=(m=t==null?void 0:t.textContent)==null?void 0:m.trim();!d&&((E=a==null?void 0:a.textContent)!=null&&E.trim())&&(d=a.textContent.trim()),d||(d="Company");const l=window.location.href.split("?")[0],f=_(Ee)!==null?"EASY_APPLY":"COMPANY_SITE";let p;if(a!=null&&a.href){const u=a.href.match(/\/company\/([^/]+)/);u&&(p=u[1])}if(o.innerHTML="✓ Added to RefLoop!",o.style.backgroundColor="#059669",!((g=chrome.runtime)!=null&&g.id)){console.warn("[RefLoop] Extension context invalidated. Please refresh the page.");return}chrome.runtime.sendMessage({type:"ADD_JOB_REQUEST",payload:{companyName:d,jobTitle:i,jobLink:l,sourceType:f,companyLinkedInSlug:p}},()=>{if(chrome.runtime.lastError){console.warn("[RefLoop] Message send error:",chrome.runtime.lastError.message);return}Re(d,i)})}),e.appendChild(o),!0}function Re(e,t){const o=document.createElement("div");o.style.cssText=`
    position: fixed;
    bottom: 24px;
    right: 24px;
    padding: 14px 20px;
    background-color: #1C1917;
    color: white;
    border-radius: 14px;
    font-size: 13px;
    font-weight: 500;
    box-shadow: 0 8px 24px rgba(0,0,0,0.25);
    z-index: 999999;
    display: flex;
    align-items: center;
    gap: 12px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  `,o.innerHTML=`
    <div>
      <div style="font-weight: 700; color: #10B981;">✓ Job Added to RefLoop!</div>
      <div style="font-size: 11px; color: #A8A29E;">${t} at ${e}</div>
    </div>
    <button id="refloop-toast-dash-btn" style="padding: 6px 12px; background: #D97757; color: white; border: none; border-radius: 8px; font-size: 12px; font-weight: 600; cursor: pointer;">Open Dashboard ↗</button>
  `,document.body.appendChild(o);const r=o.querySelector("#refloop-toast-dash-btn");r==null||r.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_DASHBOARD"}),o.remove()}),setTimeout(()=>o.remove(),6e3)}let te=!1;function Fe(){te||(te=!0,document.addEventListener("click",e=>{const t=e.target;if(!t)return;(ye.some(r=>{try{return t.matches(r)||t.closest(r)!==null}catch{return!1}})||ze(t))&&De(t)},!0))}function ze(e){try{const t=(e.textContent||"").trim(),o=e.getAttribute("aria-label")||"";return e.tagName==="BUTTON"||e.tagName==="SPAN"||e.closest("button")!==null?/^connect$/i.test(t)||/^invite$/i.test(t)||/connect/i.test(o)||/invite.*to connect/i.test(o):!1}catch{return!1}}function De(e){var d,l;const t=y()==="PROFILE_PAGE",o=t&&(e.closest(".pv-top-card, main section:first-of-type, .ph5")!==null||!e.closest('aside, .right-rail, [data-view-name*="sidebar"], [data-view-name*="more-profiles"]'));let r,n;if(t&&o)r=R().fullName,n=window.location.href.split("?")[0];else{const s=e.closest("li, .artdeco-card, .org-people-profile-card, [data-chameleon-result-item], .entity-result, .pv-top-card, main")||document.body,f=s.querySelector('.org-people-profile-card__profile-title, .entity-result__title-text a, a[href*="/in/"] span[aria-hidden="true"], .pv-text-details__left-panel h1, .pv-text-details__left-panel h2, h2, h3, h4');if((d=f==null?void 0:f.textContent)!=null&&d.trim()){const c=C(f.textContent.trim());A(c)&&(r=c)}if(!r){const c=s.querySelector('a[href*="/in/"]');if((l=c==null?void 0:c.textContent)!=null&&l.trim()){const m=C(c.textContent.trim());A(m)&&(r=m)}}const p=s.querySelector('a[href*="/in/"]');p!=null&&p.href?n=p.href.split("?")[0]:n=window.location.href.split("?")[0]}(!r||r.length<2)&&(r="Contact");let i;const a=window.location.pathname.match(/\/company\/([^/]+)/i);a&&a[1]&&(i=a[1].replace(/-/g," ")),setTimeout(()=>{V({fullName:r,profileUrl:n,companyNameHint:i})},250)}function se(){try{return new URL(window.location.href).searchParams.get("currentJobId")}catch{return null}}function Me(){var i,a,d;const e=se();if(e){const l=Array.from(document.querySelectorAll(`a[href*="/jobs/view/${e}"]`));let s=null,f=0;for(const p of l){const c=((i=p.textContent)==null?void 0:i.trim())??"";c.length>f&&(s=p,f=c.length)}if(s&&f>2)return{el:s,text:s.textContent.trim()}}const t=Array.from(document.querySelectorAll("h1"));for(const l of t){const s=((a=l.textContent)==null?void 0:a.trim())??"";if(s.length>3)return{el:l,text:s}}const o=Array.from(document.querySelectorAll('a[href*="/jobs/view/"]'));let r=null,n=0;for(const l of o){const s=((d=l.textContent)==null?void 0:d.trim())??"";s.length>n&&(r=l,n=s.length)}return r&&n>3?{el:r,text:r.textContent.trim()}:null}function qe(e){var i,a,d;let t=e.parentElement,o=0;for(;t&&o<10;){const l=t.querySelector('a[href*="/company/"]');if(l){const s=(i=l.textContent)==null?void 0:i.trim();return s&&s.length>0?s:He(l.href)}t=t.parentElement,o++}const r=Array.from(document.querySelectorAll('a[href*="/company/"]')),n=r.find(l=>!!(e.compareDocumentPosition(l)&Node.DOCUMENT_POSITION_FOLLOWING));if((a=n==null?void 0:n.textContent)!=null&&a.trim())return n.textContent.trim();for(const l of r){const s=(d=l.textContent)==null?void 0:d.trim();if(s&&s.length>0)return s}return""}function He(e){const t=e.match(/\/company\/([^/?#]+)/);return t!=null&&t[1]?t[1].split("-").map(o=>o.charAt(0).toUpperCase()+o.slice(1)).join(" "):""}function oe(){const e=Me();if(!e)return null;const{el:t,text:o}=e,r=qe(t),n=se();let i;return n?i=`${window.location.origin}/jobs/view/${n}/`:i=window.location.href.split("?")[0],{jobTitle:o,companyName:r,jobLink:i}}function le(e=8,t=500){return new Promise(o=>{const r=oe();if(r){o(r);return}let n=0;const i=setInterval(()=>{n++;const a=oe();(a||n>=e)&&(clearInterval(i),o(a))},t)})}const H="refloop-jobs-floating-widget",Be="refloop-jobs-tab",z="refloop-jobs-panel";let $=!1,B="";function $e(){M();const t=new URL(window.location.href).searchParams.get("currentJobId")??"";Je(t),t&&(B=t,pe(t))}function M(){var e;(e=document.getElementById(H))==null||e.remove(),$=!1,B=""}function Ue(){if(document.getElementById("refloop-widget-styles"))return;const e=document.createElement("style");e.id="refloop-widget-styles",e.textContent=`
    #${H} * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      line-height: normal;
    }
    @keyframes refloop-pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.3; }
    }
  `,document.head.appendChild(e)}function Je(e){if(document.getElementById(H))return;Ue();const t=document.createElement("div");t.id=H,t.style.cssText=`
    position: fixed;
    top: 50%;
    right: 0;
    transform: translateY(-50%);
    z-index: 2147483646;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    display: flex;
    flex-direction: row-reverse;
    align-items: center;
    pointer-events: none;
  `;const o=document.createElement("button");o.id=Be,o.title="RefLoop — Add Job to Tracker",o.style.cssText=`
    all: unset;
    width: 40px;
    height: 92px;
    background: linear-gradient(180deg, #E06D53 0%, #D97757 100%);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-right: none;
    border-radius: 12px 0 0 12px;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: space-between;
    padding: 10px 0;
    box-shadow: -4px 0 20px rgba(0, 0, 0, 0.3);
    transition: width 0.2s ease, background 0.2s ease, transform 0.2s ease;
    pointer-events: auto;
    flex-shrink: 0;
    box-sizing: border-box;
  `,o.innerHTML=`
    <div style="
      width: 24px;
      height: 24px;
      background: rgba(255, 255, 255, 0.22);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 13px;
      line-height: 1;
    ">⚡</div>
    <span style="
      writing-mode: vertical-rl;
      text-orientation: mixed;
      transform: rotate(180deg);
      font-size: 10px;
      font-weight: 800;
      color: #FFFFFF;
      letter-spacing: 1.5px;
      display: block;
      line-height: 1;
      text-transform: uppercase;
      margin-bottom: 2px;
    ">REFLOOP</span>
  `,o.addEventListener("mouseenter",()=>{o.style.background="linear-gradient(180deg, #C86545 0%, #BF6640 100%)",o.style.width="44px"}),o.addEventListener("mouseleave",()=>{o.style.background="linear-gradient(180deg, #E06D53 0%, #D97757 100%)",o.style.width="40px"}),o.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),Ye()}),t.appendChild(o);const r=document.createElement("div");r.id=z,r.style.cssText=`
    width: 310px;
    background: #18181B;
    border: 1px solid #3F3F46;
    border-right: none;
    border-radius: 16px 0 0 16px;
    box-shadow: -12px 0 36px rgba(0,0,0,0.5);
    padding: 20px;
    transform: translateX(100%);
    opacity: 0;
    visibility: hidden;
    pointer-events: none;
    transition: transform 0.3s cubic-bezier(0.32, 0.72, 0, 1), opacity 0.2s ease, visibility 0.3s;
    overflow: hidden;
    position: relative;
    box-sizing: border-box;
  `,r.innerHTML=N(),t.appendChild(r),document.body.appendChild(t),F(r),e&&setTimeout(()=>ce(),800)}function N(e){const t=(e==null?void 0:e.companyName)??"",o=(e==null?void 0:e.jobTitle)??"",r=(e==null?void 0:e.jobLink)??"";return e?`
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
      <div style="display:flex;align-items:center;gap:10px;min-width:0;">
        <div style="
          width:30px;height:30px;min-width:30px;
          background:linear-gradient(135deg,#E06D53,#D97757);
          border-radius:8px;
          display:flex;align-items:center;justify-content:center;
          font-size:15px;line-height:1;
        ">⚡</div>
        <div style="min-width:0;">
          <div style="font-size:13px;font-weight:700;color:#F4F4F5;line-height:1.3;">RefLoop</div>
          <div style="font-size:9px;font-weight:600;color:#D97757;letter-spacing:0.8px;line-height:1.3;">REFERRAL TRACKER</div>
        </div>
      </div>
      <button id="refloop-panel-close" style="
        all:unset;cursor:pointer;
        width:24px;height:24px;min-width:24px;
        display:flex;align-items:center;justify-content:center;
        color:#71717A;font-size:14px;line-height:1;
        border-radius:6px;
        transition:background 0.15s, color 0.15s;
      " title="Close">✕</button>
    </div>

    <div style="height:1px;background:#3F3F46;margin-bottom:16px;"></div>

    <div id="refloop-panel-form">
      <div style="margin-bottom:14px;">
        <label style="display:block;font-size:10px;font-weight:700;color:#A1A1AA;margin-bottom:6px;letter-spacing:0.8px;text-transform:uppercase;">Company</label>
        <input id="refloop-widget-company"
          type="text"
          value="${I(t)}"
          placeholder="e.g. Visa, Google"
          style="
            width:100%;box-sizing:border-box;
            padding:10px 12px;
            background:#27272A;border:1px solid #3F3F46;
            border-radius:10px;font-size:13px;color:#F4F4F5;
            font-family:inherit;outline:none;
            transition:border-color 0.15s;
          "
        />
      </div>

      <div style="margin-bottom:16px;">
        <label style="display:block;font-size:10px;font-weight:700;color:#A1A1AA;margin-bottom:6px;letter-spacing:0.8px;text-transform:uppercase;">Job Title</label>
        <input id="refloop-widget-title"
          type="text"
          value="${I(o)}"
          placeholder="e.g. Sr. Software Engineer"
          style="
            width:100%;box-sizing:border-box;
            padding:10px 12px;
            background:#27272A;border:1px solid #3F3F46;
            border-radius:10px;font-size:13px;color:#F4F4F5;
            font-family:inherit;outline:none;
            transition:border-color 0.15s;
          "
        />
      </div>

      <input id="refloop-widget-link" type="hidden" value="${I(r)}" />

      <button id="refloop-widget-submit" style="
        all:unset;
        display:flex;align-items:center;justify-content:center;gap:6px;
        width:100%;box-sizing:border-box;
        padding:11px 16px;
        background:linear-gradient(135deg,#E06D53,#D97757);
        color:white;border-radius:10px;
        font-size:13px;font-weight:700;cursor:pointer;
        box-shadow:0 4px 14px rgba(217,119,87,0.35);
        transition:opacity 0.15s,transform 0.1s;
        font-family:inherit;
        text-align:center;
      ">
        <span style="font-size:15px;line-height:1;">+</span>
        <span>Add Job to RefLoop</span>
      </button>

      <div id="refloop-widget-error" style="
        display:none;margin-top:10px;
        font-size:11px;color:#F87171;text-align:center;
      "></div>
    </div>
  `:`
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
        <div style="
          width:30px;height:30px;min-width:30px;
          background:linear-gradient(135deg,#E06D53,#D97757);
          border-radius:8px;
          display:flex;align-items:center;justify-content:center;
          font-size:15px;line-height:1;
        ">⚡</div>
        <div>
          <div style="font-size:13px;font-weight:700;color:#F4F4F5;line-height:1.3;">RefLoop</div>
          <div style="font-size:9px;font-weight:600;color:#D97757;letter-spacing:0.8px;line-height:1.3;">REFERRAL TRACKER</div>
        </div>
      </div>
      <div style="height:1px;background:#3F3F46;margin-bottom:16px;"></div>
      <div style="text-align:center;padding:24px 0;color:#71717A;font-size:12px;">
        <div style="font-size:22px;margin-bottom:10px;animation:refloop-pulse 1.2s ease-in-out infinite;">⚡</div>
        Reading job details…
      </div>
    `}function Ge(e,t){return`
    <div style="text-align:center;padding:20px 0;">
      <div style="font-size:36px;margin-bottom:10px;line-height:1;">✅</div>
      <div style="font-size:14px;font-weight:700;color:#34D399;margin-bottom:6px;line-height:1.3;">Added to RefLoop!</div>
      <div style="font-size:11px;color:#A1A1AA;margin-bottom:16px;line-height:1.4;word-break:break-word;">${I(t)} at ${I(e)}</div>
      <button id="refloop-widget-open-dash" style="
        all:unset;
        display:inline-flex;align-items:center;justify-content:center;gap:4px;
        padding:9px 18px;
        background:#27272A;border:1px solid #3F3F46;
        color:#F4F4F5;border-radius:10px;font-size:12px;font-weight:600;
        cursor:pointer;font-family:inherit;
        transition:background 0.15s;
      ">Open Dashboard <span style="font-size:14px;">↗</span></button>
    </div>
  `}function ce(){const e=document.getElementById(z);e&&(e.style.transform="translateX(0)",e.style.opacity="1",e.style.visibility="visible",e.style.pointerEvents="auto",$=!0)}function de(){const e=document.getElementById(z);e&&(e.style.transform="translateX(100%)",e.style.opacity="0",e.style.visibility="hidden",e.style.pointerEvents="none",$=!1)}function Ye(){$?de():ce()}async function pe(e){const t=document.getElementById(z);if(!t)return;t.innerHTML=N(),F(t);const o=await le();t.isConnected&&(o?t.innerHTML=N(o):t.innerHTML=N({jobTitle:"",companyName:"",jobLink:`${window.location.origin}/jobs/view/${e}/`}),F(t))}function F(e){var r;const t=e.querySelector("#refloop-panel-close");t==null||t.addEventListener("click",()=>de()),t==null||t.addEventListener("mouseenter",()=>{t.style.background="#27272A",t.style.color="#F4F4F5"}),t==null||t.addEventListener("mouseleave",()=>{t.style.background="transparent",t.style.color="#71717A"}),e.querySelectorAll('input[type="text"]').forEach(n=>{n.addEventListener("focus",()=>{n.style.borderColor="#D97757"}),n.addEventListener("blur",()=>{n.style.borderColor="#3F3F46"})});const o=e.querySelector("#refloop-widget-submit");o==null||o.addEventListener("click",()=>void We(e)),o==null||o.addEventListener("mouseenter",()=>{o&&(o.style.opacity="0.9",o.style.transform="translateY(-1px)")}),o==null||o.addEventListener("mouseleave",()=>{o&&(o.style.opacity="1",o.style.transform="translateY(0)")}),(r=e.querySelector("#refloop-widget-open-dash"))==null||r.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_DASHBOARD"})})}async function We(e){var s;const t=e.querySelector("#refloop-widget-company"),o=e.querySelector("#refloop-widget-title"),r=e.querySelector("#refloop-widget-link"),n=e.querySelector("#refloop-widget-error"),i=e.querySelector("#refloop-widget-submit"),a=(t==null?void 0:t.value.trim())??"",d=(o==null?void 0:o.value.trim())??"",l=(r==null?void 0:r.value)??window.location.href.split("?")[0];if(!a||!d){n&&(n.style.display="block",n.textContent="Please fill in both Company and Job Title.");return}if(i&&(i.style.opacity="0.6",i.style.pointerEvents="none",i.innerHTML='<span style="opacity:0.8;">Adding…</span>'),!((s=chrome.runtime)!=null&&s.id)){n&&(n.style.display="block",n.textContent="Extension context lost — please refresh the page."),i&&(i.style.opacity="1",i.style.pointerEvents="auto",i.innerHTML='<span style="font-size:15px;line-height:1;">+</span><span>Add Job to RefLoop</span>');return}try{const f=!!document.querySelector('button[aria-label*="Easy Apply" i]'),p=async(m=1)=>{try{await new Promise((E,g)=>{chrome.runtime.sendMessage({type:"ADD_JOB_REQUEST",payload:{companyName:a,jobTitle:d,jobLink:l,sourceType:f?"EASY_APPLY":"COMPANY_SITE"}},u=>{if(chrome.runtime.lastError)return g(new Error(chrome.runtime.lastError.message??"Extension runtime error"));u!=null&&u.success?E():g(new Error((u==null?void 0:u.error)??"Unknown error"))})})}catch(E){if(m>0)return await new Promise(g=>setTimeout(g,200)),p(m-1);throw E}};await p(1);const c=e.querySelector("#refloop-panel-form");c&&(c.innerHTML=Ge(a,d),F(e))}catch(f){console.error("[RefLoop] Widget submit error:",f);const p=f instanceof Error?f.message:String(f);n&&(n.style.display="block",n.textContent=p.startsWith("Error:")?p:`Error: ${p}`),i&&(i.style.opacity="1",i.style.pointerEvents="auto",i.innerHTML='<span style="font-size:15px;line-height:1;">+</span><span>Add Job to RefLoop</span>')}}function I(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function Ze(e){if(e===B)return;B=e;const t=document.getElementById(z);if(t){if(!e){t.innerHTML=N(),F(t);return}pe(e)}}let S=null,O=null,Z=[];function Ve(){if(y()!=="COMPANY_PEOPLE_PAGE"){P();return}fe(),D(),[50,150,300,600,1e3,1500,2200,3500].forEach(t=>{const o=setTimeout(()=>{y()==="COMPANY_PEOPLE_PAGE"&&D()},t);Z.push(o)}),S||(S=new MutationObserver(()=>{var t;if(!((t=chrome.runtime)!=null&&t.id)){P();return}y()==="COMPANY_PEOPLE_PAGE"&&D()}),S.observe(document.body,{childList:!0,subtree:!0})),O||(O=setInterval(()=>{var t;if(!((t=chrome.runtime)!=null&&t.id)){P();return}y()==="COMPANY_PEOPLE_PAGE"&&D()},500))}function fe(){Z.forEach(e=>clearTimeout(e)),Z=[]}function P(){fe(),S&&(S.disconnect(),S=null),O&&(clearInterval(O),O=null),document.querySelectorAll(".refloop-company-people-btn").forEach(e=>e.remove())}function Ke(){var i;const e=window.location.pathname.match(/\/(?:company|school)\/([^/]+)/i),t=e?e[1]??"":"",o=document.querySelector(".org-top-card-summary__title, h1.org-top-card-summary__title, .org-top-card-primary-content__title, .org-top-card__title, h1"),n=((i=o==null?void 0:o.textContent)==null?void 0:i.trim())||t.replace(/-/g," ");return{slug:t,name:n}}function ue(e){return!!(e===document.body||e.tagName==="MAIN"||e.tagName==="BODY"||e.tagName==="HTML"||e.classList.contains("scaffold-layout__main")||e.classList.contains("scaffold-layout__content")||e.classList.contains("org-people-profiles-module__profile-list")||e.classList.contains("org-people-directory"))}function ne(e){if(ue(e))return!1;const t=e.querySelectorAll("button");let o=0;if(t.forEach(i=>{const a=(i.textContent||"").trim().toLowerCase(),d=(i.getAttribute("aria-label")||"").toLowerCase();(a==="connect"||a==="invite"||a==="message"||a==="follow"||d.includes("connect")||d.includes("invite"))&&o++}),o>1||e.querySelectorAll('a[href*="/in/"]').length===0)return!1;const n=e.querySelector("h2, h3");if(n){const i=(n.textContent||"").trim().toLowerCase();if(i.includes("people you may know")||i.includes("people also follow"))return!1}return!0}function re(e){const t=e.closest('li.org-people-profiles-module__profile-item, li.org-people-profile-card__profile-card-spacing, .org-people-profile-card, [data-view-name*="profile-card"], .discover-entity-type-card, [data-chameleon-result-item], .org-people-profiles-module__profile-list > li');if(t&&ne(t))return t;let o=e.parentElement;for(;o&&o!==document.body&&o.tagName!=="MAIN"&&!ue(o);){if(ne(o))return o;o=o.parentElement}return null}function ie(e,t,o,r){var s,f;if(e.querySelector(".refloop-company-people-btn"))return;let n="";const i=e.querySelector('.org-people-profile-card__profile-title, .artdeco-entity-lockup__title, .discover-person-card__name, [data-view-name*="title"], h3, h4, h2, strong');if((s=i==null?void 0:i.textContent)!=null&&s.trim()){const p=C(i.textContent.trim());A(p)&&(n=p)}if(!n){const p=t.getAttribute("aria-label")||e.getAttribute("aria-label")||"",c=p.match(/View\s+(.+?)[’']s\s+profile/i)||p.match(/Invite\s+(.+?)\s+to\s+connect/i);if(c&&c[1]){const m=C(c[1].trim());A(m)&&(n=m)}}if(!n){const p=(f=t.textContent)==null?void 0:f.trim();if(p&&p.length>1){const c=C(p);A(c)&&(n=c)}}if(!n||n.length<2)return;let a=o.split("?")[0].split("#")[0];a.startsWith("http")||(a=`https://www.linkedin.com${a}`),window.getComputedStyle(e).position==="static"&&(e.style.position="relative");const l=document.createElement("button");l.className="refloop-company-people-btn",l.title=`Add ${n} to RefLoop`,l.setAttribute("aria-label",`Add ${n} to RefLoop`),l.innerHTML="⚡",l.style.cssText=`
    position: absolute;
    top: 10px;
    right: 10px;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: linear-gradient(135deg, #E06D53 0%, #D97757 100%);
    color: #ffffff;
    border: 1.5px solid #FAF8F5;
    font-size: 13px;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(217, 119, 87, 0.4);
    z-index: 100;
    transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
    opacity: 0.95;
  `,l.addEventListener("mouseenter",()=>{l.style.transform="scale(1.15)",l.style.opacity="1",l.style.boxShadow="0 4px 14px rgba(217, 119, 87, 0.6)"}),l.addEventListener("mouseleave",()=>{l.style.transform="scale(1)",l.style.opacity="0.95",l.style.boxShadow="0 2px 8px rgba(217, 119, 87, 0.4)"}),l.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),V({fullName:n,profileUrl:a,companyNameHint:r})}),e.appendChild(l)}function D(){if(y()!=="COMPANY_PEOPLE_PAGE")return;const{name:e}=Ke();Array.from(document.querySelectorAll('main a[href*="/in/"], a[href*="/in/"]')).filter(r=>!r.closest("header, nav, #global-nav, .global-nav, footer")).forEach(r=>{const n=r.getAttribute("href")||"";if(!n.includes("/in/")||n.includes("/in/unavailable/"))return;const i=re(r);i&&ie(i,r,n,e)}),Array.from(document.querySelectorAll("main button, button")).filter(r=>{if(r.closest("header, nav, #global-nav, .global-nav, footer"))return!1;const n=(r.textContent||"").trim().toLowerCase(),i=(r.getAttribute("aria-label")||"").toLowerCase();return n==="connect"||n==="invite"||i.includes("connect")||i.includes("invite")}).forEach(r=>{const n=re(r);if(!n)return;const i=n.querySelector('a[href*="/in/"]');if(!i)return;const a=i.getAttribute("href")||"";!a.includes("/in/")||a.includes("/in/unavailable/")||ie(n,i,a,e)})}const L=window;L.__refloop_heartbeat__&&(clearInterval(L.__refloop_heartbeat__),L.__refloop_heartbeat__=void 0);L.__refloop_route_observer__&&(L.__refloop_route_observer__.disconnect(),L.__refloop_route_observer__=void 0);chrome.runtime.onMessage.addListener((e,t,o)=>{if(e!==null&&typeof e=="object"){const r=e;if(r.type==="REFLOOP_NAVIGATED"){const n=r.url||window.location.href;T(!0,n);return}if(r.type==="GET_CURRENT_JOB_DETAILS")return le().then(n=>{o({success:!0,details:n})}),!0}return!1});function me(){var t,o,r,n,i,a;const e=y();e==="PROFILE_PAGE"?((t=document.getElementById("refloop-job-injector-btn"))==null||t.remove(),P(),M(),Pe()):e==="JOB_PAGE"?((o=document.getElementById("refloop-profile-floating-btn"))==null||o.remove(),P(),Ie(),$e()):e==="COMPANY_PEOPLE_PAGE"?((r=document.getElementById("refloop-job-injector-btn"))==null||r.remove(),(n=document.getElementById("refloop-profile-floating-btn"))==null||n.remove(),M(),Ve()):((i=document.getElementById("refloop-job-injector-btn"))==null||i.remove(),(a=document.getElementById("refloop-profile-floating-btn"))==null||a.remove(),P(),M()),Fe()}let Y=window.location.href,q=y();function T(e=!1,t){const o=t||window.location.href,r=y(o);if(!e&&o===Y&&r===q)return;const n=Y,i=q;Y=o,q=r;try{const a=new URL(n),d=new URL(o),l=a.searchParams.get("currentJobId")??"",s=d.searchParams.get("currentJobId")??"",f=a.pathname,p=d.pathname;if(r==="JOB_PAGE"&&i==="JOB_PAGE"&&f===p&&s!==l){Ze(s);return}}catch{}me()}me();const U=new MutationObserver(()=>{var e;if(!((e=chrome.runtime)!=null&&e.id)){U.disconnect();return}T()});U.observe(document.body,{subtree:!0,childList:!0});L.__refloop_route_observer__=U;window.addEventListener("popstate",()=>{var e;(e=chrome.runtime)!=null&&e.id&&T(!0)});window.addEventListener("hashchange",()=>{var e;(e=chrome.runtime)!=null&&e.id&&T(!0)});document.addEventListener("click",e=>{var r;if(!((r=chrome.runtime)!=null&&r.id))return;const t=e.target;if(!t)return;(t.closest("a")!==null||t.closest("button")!==null||t.closest('[role="tab"]')!==null||t.closest(".org-page-navigation")!==null||t.closest(".artdeco-tab")!==null)&&(setTimeout(()=>{var n;(n=chrome.runtime)!=null&&n.id&&T()},50),setTimeout(()=>{var n;(n=chrome.runtime)!=null&&n.id&&T()},200),setTimeout(()=>{var n;(n=chrome.runtime)!=null&&n.id&&T()},500))},!0);const be=setInterval(()=>{var e;if(!((e=chrome.runtime)!=null&&e.id)){clearInterval(be),U.disconnect();return}T()},300);L.__refloop_heartbeat__=be;console.log("[RefLoop] Content script initialized, pageType=",q);
})()
