import{c as o,j as e,B as d}from"./index-CmsZJtSC.js";/**
 * @license lucide-react v0.400.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=o("FolderOpen",[["path",{d:"m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",key:"usdka0"}]]);function x({icon:r=l,title:a,description:n,actionLabel:t,onAction:s}){return e.jsxs("div",{className:"flex flex-col items-center justify-center p-12 text-center border-2 border-dashed border-stone-200 dark:border-stone-800 rounded-xl bg-stone-50/50 dark:bg-stone-900/50",children:[e.jsx("div",{className:"flex h-12 w-12 items-center justify-center rounded-full bg-stone-100 dark:bg-stone-800 text-stone-500 mb-4",children:e.jsx(r,{className:"h-6 w-6"})}),e.jsx("h3",{className:"text-lg font-semibold text-stone-900 dark:text-stone-100 mb-1",children:a}),e.jsx("p",{className:"text-sm text-stone-500 dark:text-stone-400 max-w-sm mb-6",children:n}),t&&s&&e.jsx(d,{onClick:s,variant:"primary",children:t})]})}export{x as E};
